#!/bin/zsh
alias cloudapp=$ZSH/plugins/cloudapp/cloudapp.rb
